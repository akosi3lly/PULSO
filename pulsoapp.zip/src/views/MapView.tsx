import { useState } from 'react';
import { Building2, CalendarDays, CheckCircle2, Filter, List, Map as MapIcon, MapPin, ShieldAlert, Waves } from 'lucide-react';
import type { Report } from '../data/mockData';
import { facilities, marinduquePath } from '../data/mockData';
import { PrototypeNotice, StatusPill } from '../components/Primitives';

export function MapView({ reports }: { reports: Report[] }) {
  const [mode, setMode] = useState<'map' | 'list'>('map');
  const [filter, setFilter] = useState('All');
  const filters = ['All', 'Evacuation center', 'Health facility', 'Water point', 'Reports'];
  const visibleFacilities = facilities.filter((f) => filter === 'All' || f.type === filter);
  return <>
    <PrototypeNotice compact />
    <section className="map-toolbar"><div className="segmented"><button className={mode === 'map' ? 'active' : ''} onClick={() => setMode('map')}><MapIcon size={16} /> Map view</button><button className={mode === 'list' ? 'active' : ''} onClick={() => setMode('list')}><List size={16} /> List view</button></div><div className="filter-row"><Filter size={15} />{filters.map((item) => <button key={item} className={filter === item ? 'filter-chip filter-chip--active' : 'filter-chip'} onClick={() => setFilter(item)}>{item}</button>)}</div></section>
    <div className={`map-layout ${mode === 'list' ? 'map-layout--list' : ''}`}>
      <section className="map-panel">{mode === 'map' ? <div className="island-map"><div className="island-map__legend"><span><i className="legend-dot legend-dot--facility" /> Verified facility</span><span><i className="legend-dot legend-dot--report" /> Community report</span></div><svg viewBox="0 0 100 120" aria-label="Illustrative Marinduque map with facilities"><path className="island-map__shape" d={marinduquePath} /><path className="island-map__pulse" d="M18 67 L28 67 L34 60 L40 76 L48 54 L55 67 L65 67 L73 60" />{facilities.map((f) => <g key={f.id} transform={`translate(${f.marker[0]} ${f.marker[1]})`}><circle className="map-marker map-marker--facility" r="3.2" /><circle className="map-marker__halo" r="6" /><title>{f.name}</title></g>)}{reports.slice(0, 3).map((r, i) => <g key={r.id} transform={`translate(${24 + i * 22} ${70 - i * 8})`}><circle className="map-marker map-marker--report" r="2.7" /><title>{r.category}</title></g>)}</svg><div className="island-map__caption"><strong>Marinduque pilot area</strong><span>Symbolic geography for prototype navigation · not an official hazard layer</span></div></div> : <div className="list-fallback"><div className="list-fallback__intro"><span className="eyebrow">Low-bandwidth fallback</span><h2>Facilities you can explain over a phone call.</h2><p>Every record shows the source and last verification date. Confirm current status before relying on it.</p></div>{visibleFacilities.map((facility) => <FacilityRow key={facility.id} facility={facility} />)}{filter === 'Reports' && reports.map((report) => <article className="facility-row" key={report.id}><div className="facility-row__icon facility-row__icon--report"><ShieldAlert size={18} /></div><div><strong>{report.category}</strong><span>{report.area} · {report.id}</span><small>Report status: {report.status} · {report.createdAt}</small></div><StatusPill label={report.status} /></article>)}</div>}</section>
      <aside className="map-side"><div className="map-side__head"><div><p className="eyebrow">Directory</p><h2>{filter === 'All' ? 'Verified facilities' : filter}</h2></div><span className="count-badge">{filter === 'Reports' ? reports.length : visibleFacilities.length}</span></div>{filter !== 'Reports' && visibleFacilities.map((facility) => <FacilityRow key={facility.id} facility={facility} compact />)}<div className="map-disclaimer"><CheckCircle2 size={16} /><p><strong>Use with care.</strong> Facility status is demo data and may be outdated. This map is not an evacuation order.</p></div></aside>
    </div>
  </>;
}

function FacilityRow({ facility, compact = false }: { facility: typeof facilities[number]; compact?: boolean }) {
  return <article className={`facility-row ${compact ? 'facility-row--compact' : ''}`}><div className={`facility-row__icon ${facility.type === 'Water point' ? 'facility-row__icon--leaf' : ''}`}>{facility.type === 'Water point' ? <Waves size={18} /> : facility.type === 'Health facility' ? <Building2 size={18} /> : <MapPin size={18} />}</div><div><strong>{facility.name}</strong><span>{facility.type} · {facility.area}</span><small><CalendarDays size={12} /> Checked {facility.verified} · {facility.source}</small></div><span className={`facility-status ${facility.status.includes('Needs') ? 'facility-status--check' : ''}`}><span />{facility.status}</span></article>;
}
