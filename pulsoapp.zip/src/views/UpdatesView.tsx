import { ArrowUpRight, BellRing, CheckCircle2, Clock3, Info, Link2 } from 'lucide-react';
import { advisory } from '../data/mockData';
import { ExternalLink, PrototypeNotice, SourceStamp } from '../components/Primitives';

const updates = [
  { label: 'Official advisory', tone: 'official', issuer: advisory.issuer, title: advisory.title, time: advisory.issued, scope: advisory.affected, summary: advisory.summary, source: advisory.sourceUrl, fresh: true },
  { label: 'Local information', tone: 'local', issuer: 'Boac Municipal DRRM Office · prototype feed', title: 'Keep the market approach visible for morning coordination', time: '09 Oct 2026 · 18:10', scope: 'Boac · Poblacion', summary: 'PULSO summary: a local focal is checking whether the low section remains passable. This note is not an official hazard assessment.', source: 'https://www.pagasa.dost.gov.ph/products-and-services', fresh: false },
  { label: 'Reference context', tone: 'context', issuer: 'GeoRiskPH / HazardHunterPH', title: 'Indicative hazard information is available for planning', time: 'Reference tool · check current date', scope: 'Philippines · planning context', summary: 'Use official tools for indicative planning context and preserve their intended use. PULSO does not reproduce or certify hazard layers in this prototype.', source: 'https://hazardhunter.georisk.gov.ph/about-hazardhunterph', fresh: false },
];

export function UpdatesView() {
  return <>
    <PrototypeNotice compact />
    <section className="updates-top"><div><span className="eyebrow">Provenance first</span><h2>Official information stays attached to its source.</h2><p>When PULSO provides a plain-language summary, it is labeled as a summary. The original title, issuer, link, and timestamps remain accessible.</p></div><div className="updates-key"><span><i className="legend-dot legend-dot--official" /> Official</span><span><i className="legend-dot legend-dot--local" /> Local note</span><span><i className="legend-dot legend-dot--context" /> Planning context</span></div></section>
    <section className="updates-feed">{updates.map((update) => <article className={`update-card update-card--${update.tone}`} key={update.title}><div className="update-card__top"><span className="update-label"><span />{update.label}</span>{update.fresh ? <span className="fresh-badge"><CheckCircle2 size={14} /> Freshly retrieved</span> : <span className="stale-badge"><Clock3 size={14} /> Check current source</span>}</div><h3>{update.title}</h3><div className="update-meta"><span><Info size={14} /> {update.issuer}</span><span><Clock3 size={14} /> {update.time}</span><span><Link2 size={14} /> {update.scope}</span></div><div className="update-summary"><strong>PULSO context</strong><p>{update.summary}</p></div><div className="update-card__footer"><ExternalLink href={update.source}>Open source</ExternalLink><button className="text-button">Save for later <BellRing size={14} /></button></div></article>)}</section>
    <div className="source-note"><ArrowUpRight size={16} /><span>For live warnings and instructions, use the appropriate official agency or local-government channel.</span></div>
  </>;
}
