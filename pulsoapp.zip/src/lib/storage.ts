import type { Report, ReportStatus } from '../data/mockData';
import { seedReports } from '../data/mockData';

const REPORTS_KEY = 'pulso.reports.v1';
const SETTINGS_KEY = 'pulso.settings.v1';

export function loadReports(): Report[] {
  try {
    const raw = localStorage.getItem(REPORTS_KEY);
    return raw ? JSON.parse(raw) as Report[] : seedReports;
  } catch {
    return seedReports;
  }
}

export function saveReports(reports: Report[]) {
  localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
}

export function loadSettings() {
  try {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') as { online?: boolean; role?: string; area?: string; lastSync?: string };
  } catch {
    return {};
  }
}

export function saveSettings(settings: Record<string, unknown>) {
  const next = { ...loadSettings(), ...settings };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
}

export function createReportId() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const suffix = Array.from({ length: 5 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join('');
  return `PLS-${suffix}`;
}

export function transitionReport(report: Report, status: ReportStatus, note: string): Report {
  return {
    ...report,
    status,
    events: [...report.events, { status, at: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), note }],
  };
}
