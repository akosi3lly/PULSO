import React, { useMemo, useState } from 'react';
import type { Report, Role } from './data/mockData';
import { seedReports } from './data/mockData';
import { loadReports, loadSettings, saveReports, saveSettings, transitionReport } from './lib/storage';
import { Shell, type ViewKey } from './components/Shell';
import { HomeView } from './views/HomeView';
import { MapView } from './views/MapView';
import { ReportView } from './views/ReportView';
import { PreparednessView } from './views/PreparednessView';
import { UpdatesView } from './views/UpdatesView';
import { OperationsView } from './views/OperationsView';
import { SituationReportView } from './views/SituationReportView';

function routeToView(): ViewKey {
  const route = window.location.pathname.replace(/^\//, '') as ViewKey;
  return ['map', 'report', 'preparedness', 'updates', 'operations', 'situation-report'].includes(route) ? route : 'home';
}

export default function App() {
  const settings = loadSettings();
  const [view, setView] = useState<ViewKey>(routeToView());
  const [role, setRoleState] = useState<Role>((settings.role as Role) || 'Reporter');
  const [online, setOnlineState] = useState(settings.online ?? true);
  const [lastSync, setLastSync] = useState(settings.lastSync || 'just now');
  const [reports, setReports] = useState<Report[]>(() => loadReports());
  const pendingCount = reports.filter((r) => r.status === 'Queued offline').length;

  const setRole = (next: Role) => { setRoleState(next); saveSettings({ role: next }); if (next !== 'Official' && (view === 'operations' || view === 'situation-report')) setView('home'); };
  const setOnline = (next: boolean) => { setOnlineState(next); saveSettings({ online: next }); };
  const updateReports = (next: Report[]) => { setReports(next); saveReports(next); };
  const onSync = () => {
    if (!online || !pendingCount) return;
    const next = reports.map((report) => report.status === 'Queued offline' ? transitionReport(report, 'Received', 'Local outbox synchronized when connectivity returned.') : report);
    updateReports(next); const synced = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); setLastSync(synced); saveSettings({ lastSync: synced });
  };
  const addReport = (report: Report) => updateReports([report, ...reports]);
  const updateReport = (id: string, updater: (r: Report) => Report) => updateReports(reports.map((r) => r.id === id ? updater(r) : r));
  const activeReports = useMemo(() => reports, [reports]);
  let content: React.ReactNode;
  if (view === 'home') content = <HomeView reports={activeReports} setView={setView} online={online} />;
  if (view === 'map') content = <MapView reports={activeReports} />;
  if (view === 'report') content = <ReportView role={role} online={online} onCreated={addReport} />;
  if (view === 'preparedness') content = <PreparednessView />;
  if (view === 'updates') content = <UpdatesView />;
  if (view === 'operations') content = <OperationsView reports={activeReports} onUpdate={updateReport} />;
  if (view === 'situation-report') content = <SituationReportView reports={activeReports} />;
  return <Shell view={view} setView={setView} role={role} setRole={setRole} online={online} setOnline={setOnline} pendingCount={pendingCount} lastSync={lastSync} onSync={onSync}>{content}</Shell>;
}
