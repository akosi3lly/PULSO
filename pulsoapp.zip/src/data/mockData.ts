export const marinduquePath = 'M 62.78 106.45 L 61.52 107.01 L 58.86 106.58 L 56.21 106.81 L 54.26 105.41 L 52.44 105.44 L 50.52 104.83 L 49.10 103.01 L 47.36 101.82 L 46.47 101.75 L 46.40 100.56 L 45.33 100.33 L 44.45 97.60 L 42.53 94.44 L 40.15 93.18 L 36.51 92.44 L 31.30 88.35 L 26.55 87.82 L 21.01 85.24 L 19.90 83.69 L 17.87 78.66 L 16.10 76.39 L 15.14 73.93 L 13.90 72.72 L 9.50 70.14 L 9.17 68.22 L 10.34 63.41 L 9.86 60.66 L 10.51 58.53 L 10.62 55.42 L 9.60 51.63 L 9.76 49.78 L 9.12 47.71 L 7.00 44.15 L 7.38 43.61 L 10.26 43.39 L 7.35 43.16 L 7.05 42.58 L 9.23 39.39 L 12.41 36.84 L 13.90 35.07 L 15.12 32.51 L 14.38 31.35 L 15.40 31.30 L 15.50 29.86 L 16.20 29.23 L 16.91 29.28 L 16.38 28.87 L 16.48 28.54 L 17.77 28.29 L 17.97 27.15 L 16.94 26.44 L 17.06 25.43 L 19.16 25.33 L 19.39 24.65 L 20.98 24.09 L 20.81 22.25 L 21.82 21.64 L 22.25 21.89 L 23.06 20.65 L 22.15 19.90 L 21.03 20.83 L 20.10 20.83 L 19.42 21.49 L 20.35 21.84 L 20.05 22.88 L 19.47 22.63 L 18.08 20.60 L 19.42 20.68 L 20.73 18.18 L 18.81 16.36 L 18.45 14.59 L 19.95 14.33 L 20.93 12.99 L 22.45 13.09 L 23.23 14.91 L 24.22 15.75 L 24.12 16.25 L 23.18 16.76 L 23.28 17.39 L 24.25 17.72 L 24.95 16.91 L 26.32 18.00 L 26.65 17.49 L 26.37 16.43 L 27.05 15.98 L 27.05 17.44 L 27.96 18.43 L 27.56 19.21 L 29.18 20.48 L 28.19 20.60 L 28.59 21.51 L 29.78 22.55 L 32.39 22.80 L 32.94 23.74 L 33.88 24.12 L 35.30 24.04 L 35.88 23.51 L 35.52 22.30 L 36.74 21.49 L 36.51 20.15 L 37.12 19.57 L 38.30 19.84 L 38.94 20.58 L 40.05 20.58 L 39.52 21.49 L 40.61 22.75 L 43.01 22.37 L 45.31 23.33 L 45.99 23.23 L 46.12 18.48 L 47.23 16.20 L 47.96 15.60 L 48.19 15.95 L 46.75 18.56 L 46.62 22.68 L 49.81 25.33 L 51.99 24.35 L 54.51 24.95 L 54.64 23.84 L 53.68 22.50 L 54.74 21.67 L 57.60 21.72 L 56.18 21.16 L 55.88 20.02 L 56.38 18.83 L 57.40 18.30 L 58.18 18.81 L 58.43 19.54 L 59.29 19.72 L 61.39 21.44 L 61.70 22.32 L 62.71 22.53 L 63.34 23.44 L 63.26 24.30 L 64.10 25.99 L 60.94 27.38 L 63.09 27.78 L 66.60 27.03 L 67.16 27.56 L 67.44 28.82 L 67.13 29.20 L 69.71 34.16 L 69.38 34.66 L 68.37 34.26 L 67.84 33.37 L 66.40 33.22 L 65.77 33.90 L 66.07 34.74 L 67.06 34.89 L 68.27 36.26 L 69.21 35.35 L 69.03 36.10 L 69.71 36.36 L 71.08 35.90 L 73.98 36.81 L 73.20 35.47 L 73.55 34.46 L 74.46 33.83 L 76.92 33.47 L 79.04 35.12 L 82.15 36.56 L 82.81 37.65 L 86.37 40.68 L 87.23 42.12 L 87.56 43.87 L 86.65 45.79 L 84.45 46.09 L 85.39 47.10 L 84.71 49.58 L 83.06 49.05 L 81.82 47.58 L 80.84 47.31 L 80.23 47.84 L 80.84 49.08 L 80.51 50.62 L 81.47 51.73 L 82.83 52.16 L 83.01 53.48 L 85.03 54.13 L 85.97 56.66 L 86.00 57.93 L 86.30 57.65 L 87.89 58.69 L 88.45 58.13 L 89.99 58.00 L 91.41 58.81 L 90.09 61.21 L 91.10 62.05 L 92.01 61.64 L 93.00 63.39 L 92.32 64.05 L 91.61 63.57 L 90.29 63.67 L 87.26 65.77 L 86.45 67.46 L 86.40 69.79 L 85.34 70.60 L 85.39 71.45 L 84.23 72.44 L 83.54 72.31 L 82.68 72.87 L 80.63 74.84 L 79.19 75.30 L 78.08 75.17 L 77.83 76.36 L 76.01 78.16 L 72.52 79.70 L 71.38 81.85 L 71.41 84.30 L 70.19 85.69 L 67.56 86.50 L 66.83 87.26 L 66.22 88.42 L 66.17 89.79 L 68.75 92.75 L 68.42 96.29 L 65.74 102.68 L 62.78 106.45 Z';

export type Role = 'Resident' | 'Reporter' | 'Official';
export type ReportStatus = 'Draft' | 'Queued offline' | 'Received' | 'Under verification' | 'Verified' | 'Assigned' | 'Action in progress' | 'Resolved' | 'Closed' | 'Rejected or duplicate';
export type ReportCategory = 'Flooding / rising water' | 'Blocked road or bridge damage' | 'Landslide / slope concern' | 'Fire' | 'Damaged house or public facility' | 'Power / telecommunications outage' | 'Water or sanitation problem' | 'Medical or welfare concern' | 'Missing or stranded person' | 'Agriculture damage' | 'Boat, gear, or fisheries damage' | 'Other local concern';
export type Urgency = 'Routine' | 'Watch' | 'Urgent';

export type ReportEvent = { status: ReportStatus; at: string; note: string };
export type Report = {
  id: string;
  category: ReportCategory;
  area: string;
  description: string;
  observedAt: string;
  urgency: Urgency;
  danger: boolean;
  reporterRole: Role;
  contact?: string;
  status: ReportStatus;
  createdAt: string;
  source: 'Prototype demo' | 'Local outbox';
  assignedTo?: string;
  internalNote?: string;
  events: ReportEvent[];
};

export const categories: ReportCategory[] = ['Flooding / rising water', 'Blocked road or bridge damage', 'Landslide / slope concern', 'Fire', 'Damaged house or public facility', 'Power / telecommunications outage', 'Water or sanitation problem', 'Medical or welfare concern', 'Missing or stranded person', 'Agriculture damage', 'Boat, gear, or fisheries damage', 'Other local concern'];
export const areas = ['Boac · Poblacion', 'Mogpog · Argao', 'Gasan · Bognuyan', 'Buenavista · Sihi', 'Santa Cruz · Masalukot', 'Torrijos · Poctoy'];

export const advisory = {
  issuer: 'Marinduque Provincial DRRM Office',
  title: 'Rainfall and river watch: keep local routes visible',
  issued: '10 Oct 2026 · 06:30',
  affected: 'Province-wide · localized low-lying areas',
  retrieved: '10 Oct 2026 · 06:42',
  sourceUrl: 'https://www.pagasa.dost.gov.ph/products-and-services',
  summary: 'PULSO summary: keep household routes and access points clear, and report rising water with an approximate location. This is a prototype summary, not an additional official warning.',
};

export const facilities = [
  { id: 'f1', name: 'Boac Municipal Evacuation Center', type: 'Evacuation center', area: 'Boac · Poblacion', status: 'Open for coordination', verified: '08 Oct 2026', source: 'Boac MDRRMO demo registry', marker: [44, 44] },
  { id: 'f2', name: 'Marinduque Provincial Hospital', type: 'Health facility', area: 'Boac · Santol', status: 'Operating', verified: '07 Oct 2026', source: 'Provincial health office demo registry', marker: [51, 52] },
  { id: 'f3', name: 'Mogpog Water Refill Point', type: 'Water point', area: 'Mogpog · Argao', status: 'Operating', verified: '05 Oct 2026', source: 'Mogpog LGU demo registry', marker: [30, 34] },
  { id: 'f4', name: 'Poctoy Covered Court', type: 'Assembly area', area: 'Torrijos · Poctoy', status: 'Needs re-check', verified: '28 Sep 2026', source: 'Torrijos barangay demo registry', marker: [62, 74] },
];

export const seedReports: Report[] = [
  { id: 'PLS-8K3M2', category: 'Blocked road or bridge damage', area: 'Mogpog · Argao', description: 'Small fallen branch and mud across the eastern approach; motorcycles can pass slowly.', observedAt: '10 Oct 2026 · 05:55', urgency: 'Watch', danger: false, reporterRole: 'Reporter', status: 'Under verification', createdAt: '10 Oct 2026 · 06:05', source: 'Prototype demo', assignedTo: 'Mogpog MDRRMO', events: [{ status: 'Received', at: '06:05', note: 'Submitted by trained barangay reporter.' }, { status: 'Under verification', at: '06:22', note: 'Queued for barangay confirmation.' }] },
  { id: 'PLS-2Q9N7', category: 'Flooding / rising water', area: 'Boac · Poblacion', description: 'Water is covering the lowest section near the public market entrance.', observedAt: '10 Oct 2026 · 06:18', urgency: 'Urgent', danger: true, reporterRole: 'Reporter', status: 'Assigned', createdAt: '10 Oct 2026 · 06:24', source: 'Prototype demo', assignedTo: 'Boac MDRRMO', events: [{ status: 'Received', at: '06:24', note: 'Report receipt generated.' }, { status: 'Verified', at: '06:39', note: 'Confirmed by phone call with area focal.' }, { status: 'Assigned', at: '06:45', note: 'Assigned to Boac MDRRMO.' }] },
  { id: 'PLS-4B1T6', category: 'Agriculture damage', area: 'Gasan · Bognuyan', description: 'Saltwater intrusion affected a small low-lying vegetable plot after overnight rain.', observedAt: '09 Oct 2026 · 16:40', urgency: 'Routine', danger: false, reporterRole: 'Reporter', status: 'Received', createdAt: '09 Oct 2026 · 17:02', source: 'Prototype demo', events: [{ status: 'Received', at: '17:02', note: 'Received by PULSO demo queue.' }] },
];

export const guides = [
  { id: 'before', title: 'Before heavy rain', eyebrow: 'Prepare', body: 'Charge phones and lights, agree on a family contact, keep medicines and important documents dry, and check the safest route to a verified facility.' },
  { id: 'during', title: 'During an incident', eyebrow: 'Stay clear', body: 'Follow official instructions, avoid moving water and unstable slopes, and share an approximate location only when it is safe to observe.' },
  { id: 'report', title: 'Make a useful report', eyebrow: 'Help verify', body: 'Say what you observed, where and when you saw it, what is immediately dangerous, and what responders may need to know. Avoid names and precise household details.' },
];

export const contacts = [
  { label: 'Marinduque Provincial DRRM Office', value: '(042) 332-1021', note: 'Confirm current operational numbers before pilot launch.' },
  { label: 'Philippine Red Cross · Marinduque', value: 'Official source link', note: 'Use the current chapter contact information.' },
  { label: 'PAGASA products and services', value: 'pagasa.dost.gov.ph', note: 'Official weather information and advisories.' },
  { label: 'HazardHunterPH', value: 'hazardhunter.georisk.gov.ph', note: 'Indicative planning context; not real-time ground truth.' },
];

export const statusTone = (status: ReportStatus | string) => {
  if (status.includes('Urgent') || status === 'Action in progress') return 'coral';
  if (status === 'Verified' || status === 'Assigned' || status === 'Resolved') return 'leaf';
  if (status === 'Queued offline' || status === 'Draft') return 'sand';
  if (status === 'Rejected or duplicate') return 'muted';
  return 'blue';
};
