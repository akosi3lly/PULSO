import { Bell, BookOpen, ChevronDown, ClipboardList, CloudOff, Compass, FileText, Home, Map, Menu, RefreshCw, ShieldCheck, X } from 'lucide-react';
import type { Role } from '../data/mockData';
import { BrandMark, Wordmark } from './BrandMark';

export type ViewKey = 'home' | 'map' | 'report' | 'preparedness' | 'updates' | 'operations' | 'situation-report';

const navItems: { key: ViewKey; label: string; icon: typeof Home; official?: boolean }[] = [
  { key: 'home', label: 'Home', icon: Home },
  { key: 'map', label: 'Community map', icon: Map },
  { key: 'report', label: 'Report', icon: ClipboardList },
  { key: 'preparedness', label: 'Preparedness', icon: BookOpen },
  { key: 'updates', label: 'Updates', icon: Bell },
  { key: 'operations', label: 'Operations', icon: ShieldCheck, official: true },
  { key: 'situation-report', label: 'Situation report', icon: FileText, official: true },
];

const pageTitles: Record<ViewKey, { eyebrow: string; title: string; description: string }> = {
  home: { eyebrow: 'Local information layer', title: 'See what needs attention in your area.', description: 'A calm, shared view for reports, advisories, facilities, and the next useful action.' },
  map: { eyebrow: 'Place and access', title: 'A map you can explain.', description: 'Facilities and observations shown with source, date, and limitations — plus a list when maps are not practical.' },
  report: { eyebrow: 'Observe → report', title: 'Record an observation, even without signal.', description: 'Keep it approximate, factual, and safe. A human verifies every report before it becomes an operational record.' },
  preparedness: { eyebrow: 'Ready together', title: 'Small steps that make a difference.', description: 'Plain-language guidance and contacts for before, during, and after common hazards.' },
  updates: { eyebrow: 'Official sources', title: 'Updates with provenance.', description: 'Official information stays linked to its issuer. PULSO adds context without pretending to certify risk.' },
  operations: { eyebrow: 'Authorized view · operations', title: 'A working queue, not just a dashboard.', description: 'Review, verify, assign, and preserve the record of what happened.' },
  'situation-report': { eyebrow: 'Authorized view · draft', title: 'Turn verified reports into a clear brief.', description: 'A reviewable situation-report draft for coordination — not an official submission.' },
};

export function Shell({ view, setView, role, setRole, online, setOnline, pendingCount, lastSync, onSync, children }: { view: ViewKey; setView: (v: ViewKey) => void; role: Role; setRole: (r: Role) => void; online: boolean; setOnline: (v: boolean) => void; pendingCount: number; lastSync: string; onSync: () => void; children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const title = pageTitles[view];
  const visibleItems = navItems.filter((item) => !item.official || role === 'Official');
  const navigate = (next: ViewKey) => { setView(next); setMobileOpen(false); window.history.pushState({}, '', next === 'home' ? '/' : `/${next}`); };
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'sidebar--open' : ''}`}>
      <div className="sidebar__brand"><BrandMark size={36} compact /><div><Wordmark small /><span>MARINDUQUE / PH</span></div><button className="icon-button sidebar__close" onClick={() => setMobileOpen(false)} aria-label="Close navigation"><X size={18} /></button></div>
      <div className="sidebar__tagline">Ang pintig ng<br />islangbayang ligtas!</div>
      <nav className="nav-list" aria-label="Main navigation">{visibleItems.map((item) => { const Icon = item.icon; return <button key={item.key} className={`nav-item ${view === item.key ? 'nav-item--active' : ''} ${item.official ? 'nav-item--official' : ''}`} onClick={() => navigate(item.key)}><Icon size={18} /><span>{item.label}</span>{item.official && <span className="nav-item__badge">OFFICIAL</span>}</button>; })}</nav>
      <div className="sidebar__footer"><div className="sidebar__location"><Compass size={16} /><span><strong>Marinduque</strong><small>Selected pilot area</small></span><ChevronDown size={15} /></div><div className="sidebar__source">Local coordination layer<br /><span>Not an evacuation order</span></div></div>
    </aside>
    {mobileOpen && <button className="sidebar-scrim" onClick={() => setMobileOpen(false)} aria-label="Close navigation overlay" />}
    <main className="main-content">
      <header className="topbar"><button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={20} /></button><div className="topbar__crumb"><span>{title.eyebrow}</span><span className="topbar__slash">/</span><strong>{role} preview</strong></div><div className="topbar__actions"><button className={`connectivity ${online ? 'connectivity--online' : 'connectivity--offline'}`} onClick={() => setOnline(!online)} title="Toggle prototype connectivity"><span className="connectivity__dot" />{online ? 'Online' : 'Offline'}<small>{pendingCount ? `${pendingCount} queued` : 'No queued reports'}</small></button><button className="sync-button" onClick={onSync} disabled={!online || !pendingCount}><RefreshCw size={15} className={pendingCount && online ? 'sync-button__icon--ready' : ''} /> Sync now</button><label className="role-select"><span>Role</span><select value={role} onChange={(e) => setRole(e.target.value as Role)}><option>Resident</option><option>Reporter</option><option>Official</option></select></label></div></header>
      <section className="page-header"><div><p className="eyebrow">{title.eyebrow}</p><h1>{title.title}</h1><p className="page-header__description">{title.description}</p></div><div className="page-header__status"><div className="pulse-line"><span /><i /><span /><b /></div><span>THE LIVING PULSE OF MARINDUQUE</span><small>Last sync {lastSync}</small></div></section>
      {children}
    </main>
  </div>;
}

import React from 'react';
