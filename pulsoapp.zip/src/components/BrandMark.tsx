import { marinduquePath } from '../data/mockData';

type BrandMarkProps = { size?: number; compact?: boolean; mono?: boolean; className?: string };

export function BrandMark({ size = 42, compact = false, mono = false, className = '' }: BrandMarkProps) {
  return (
    <span className={`brand-mark ${compact ? 'brand-mark--compact' : ''} ${className}`} style={{ width: size, height: size * 1.14 }} aria-label="PULSO Marinduque mark">
      <svg viewBox="0 0 100 120" role="img" aria-hidden="true">
        <path className="brand-mark__island" d={marinduquePath} />
        {!compact && <path className={`brand-mark__pulse ${mono ? 'brand-mark__pulse--mono' : ''}`} d="M18 67 L28 67 L34 60 L40 76 L48 54 L55 67 L65 67 L73 60" />}
        {!compact && <circle className={`brand-mark__dot ${mono ? 'brand-mark__dot--mono' : ''}`} cx="73" cy="60" r="4" />}
      </svg>
    </span>
  );
}

export function Wordmark({ small = false }: { small?: boolean }) {
  return <span className={`wordmark ${small ? 'wordmark--small' : ''}`}>PULSO</span>;
}
