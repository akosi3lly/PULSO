import { ArrowUpRight, Clock3, Database, WifiOff } from 'lucide-react';
import { statusTone } from '../data/mockData';

export function StatusPill({ label }: { label: string }) {
  return <span className={`status-pill status-pill--${statusTone(label)}`}><span className="status-pill__dot" />{label}</span>;
}

export function SourceStamp({ issuer, time, stale = false }: { issuer: string; time: string; stale?: boolean }) {
  return <div className="source-stamp"><span><Database size={13} /> {issuer}</span><span><Clock3 size={13} /> {time}</span>{stale && <span className="source-stamp__stale">Stale / verify before use</span>}</div>;
}

export function PrototypeNotice({ compact = false }: { compact?: boolean }) {
  return <div className={`prototype-notice ${compact ? 'prototype-notice--compact' : ''}`}><span className="prototype-notice__icon"><WifiOff size={15} /></span><span><strong>Prototype / demo data.</strong> PULSO complements official sources; it does not issue warnings or dispatch emergency services.</span></div>;
}

export function ExternalLink({ href, children }: { href: string; children: React.ReactNode }) {
  return <a className="external-link" href={href} target="_blank" rel="noreferrer">{children}<ArrowUpRight size={14} /></a>;
}
